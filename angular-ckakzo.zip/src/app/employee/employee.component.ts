import { Component } from '@angular/core';

@Component({
  selector : 'employee',
  templateUrl:'./employee.component.html',
})
export class EmployeeComponent{
  message  = 'this is employee component';
}